# SAT Solver Comparison

Acest proiect conține implementări în C++ pentru trei algoritmi de rezolvare a problemei SAT:
- Davis–Putnam (dp.cpp)
- DPLL (dpll.cpp)
- Rezoluție (rezolutie.cpp)

## Structură
- `src/` – Codurile sursă
- `tests/` – Formule de test în format `.cnf`
- `results/` – Rezultate în `.csv` și `.tex`

## Compilare
```bash
g++ src/dp.cpp -o dp
g++ src/dpll.cpp -o dpll
g++ src/rezolutie.cpp -o rezolutie
```
